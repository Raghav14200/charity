Open index.html to view the project
